<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
    <script src="/assets/js/bootstrap.min.js?v=3.3.5"></script>
    <script src="/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/assets/js/plugins/layer/layer.min.js"></script>
    <script src="/assets/js/hplus.min.js?v=4.0.0"></script>
    <script type="text/javascript" src="/assets/js/contabs.min.js"></script>
    <script src="/assets/js/plugins/pace/pace.min.js"></script>