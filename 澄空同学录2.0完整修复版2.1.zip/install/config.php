<?php
return array(
	//'配置项'=>'配置值'
	'db_host'               =>  '==host==',
	// 数据库地址
    'db_name'               =>  '==name==',
	// 数据库名称
    'db_user'               =>  '==user==',
	// 用户名
    'db_pwd'                =>  '==pwd==',
	// 密码
    'db_port'               =>  '==port==',
	// 数据库端口
    'db_prefix'             =>  '==prefix==',
	// 数据库表前缀 
);