set names 'utf8';
DROP TABLE IF EXISTS `ssnh_users`;
CREATE TABLE `ssnh_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `daili` tinyint(1) DEFAULT '0',
  `vip` tinyint(1) DEFAULT '0',
  `vipstart` date DEFAULT NULL,
  `vipend` date DEFAULT NULL,
  `rmb` int(5) DEFAULT '0',
  `peie` tinyint(2) DEFAULT '1',
  `pwd` varchar(40) NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `fuzhan` tinyint(1) DEFAULT '0',
  `login` tinyint(255) DEFAULT '1',
  `mail` varchar(100) DEFAULT NULL,
  `qq` varchar(255) DEFAULT '0',
  `phone` varchar(255) DEFAULT '0',
  `city` varchar(50) DEFAULT NULL,
  `regip` varchar(50) DEFAULT NULL,
  `lastip` varchar(50) DEFAULT NULL,
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `ah` text,
  `zz` varchar(255) NOT NULL,
  `lxdh` varchar(255) NOT NULL,
   `tc` varchar(255) NOT NULL,
   `xz` varchar(255) NOT NULL,
   `sr` varchar(255) NOT NULL,
   `xm` varchar(255) NOT NULL,
   `ch` varchar(255) NOT NULL,
   `xb` varchar(255) NOT NULL,
   `xh` varchar(255) NOT NULL,
   `zw` varchar(255) NOT NULL,
   `ktc` varchar(255) NOT NULL,
   `gxqm` varchar(255) NOT NULL,
   `tj` varchar(255) NOT NULL,
   `xtj` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `ssnh_webconfigs`;
CREATE TABLE `ssnh_webconfigs` (
  `vkey` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`vkey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `ssnh_users` (`uid`, `user`, `daili`, `vip`, `vipstart`, `vipend`, `rmb`, `peie`, `pwd`, `sid`, `active`, `fuzhan`, `login`, `mail`, `qq`, `phone`, `city`, `regip`, `lastip`, `regtime`, `lasttime`, `ah`, `zz`, `lxdh`, `tc`, `xz`, `sr`, `xm`, `ch`, `xb`, `xh`, `zw`, `ktc`, `gxqm`, `tj`, `xtj`) VALUES
(1, 'admin', 0, 1, NULL, '2020-12-30', 9999, 127, '4d3ea8f0d1aa6fa07b6c0a5375645c48', '0b484609853c70cd87c8d1e3b2f5f34a', 9, 1, 1, '2839868773@qq.com', '2839868773', '13777930544', NULL, NULL, '111.121.85.149', NULL, '2017-10-01 20:21:47', '电影', '浙江省宁波市', '13777930544', 'IT互联网', '处女座', '9月22日', '澄空' , '澄空', '1', '11', '无', '为梦想而生', '梦想是要有的，万一见鬼了呢？' , '技术大咖', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('cronrand', '1234');
INSERT INTO `ssnh_webconfigs` VALUES ('regpeie', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('zannet', '3');
INSERT INTO `ssnh_webconfigs` VALUES ('netnum', '200');
INSERT INTO `ssnh_webconfigs` VALUES ('mail_email', '');
INSERT INTO `ssnh_webconfigs` VALUES ('mail_pwd', '');
INSERT INTO `ssnh_webconfigs` VALUES ('mail_host', '');
INSERT INTO `ssnh_webconfigs` VALUES ('mail_port', '');
INSERT INTO `ssnh_webconfigs` VALUES ('do', 'set');
INSERT INTO `ssnh_webconfigs` VALUES ('price_1vip', '8');
INSERT INTO `ssnh_webconfigs` VALUES ('price_3vip', '20');
INSERT INTO `ssnh_webconfigs` VALUES ('price_6vip', '30');
INSERT INTO `ssnh_webconfigs` VALUES ('price_12vip', '50');
INSERT INTO `ssnh_webconfigs` VALUES ('price_1peie', '20');
INSERT INTO `ssnh_webconfigs` VALUES ('price_3peie', '40');
INSERT INTO `ssnh_webconfigs` VALUES ('price_5peie', '50');
INSERT INTO `ssnh_webconfigs` VALUES ('price_10peie', '66');
INSERT INTO `ssnh_webconfigs` VALUES ('submit', '确认修改');
INSERT INTO `ssnh_webconfigs` VALUES ('webfoot', 'All Right Reserved');
INSERT INTO `ssnh_webconfigs` VALUES ('webkey', '');
INSERT INTO `ssnh_webconfigs` VALUES ('web_quanquanjk', '');
INSERT INTO `ssnh_webconfigs` VALUES ('webname', '澄空同学录V2.0');
INSERT INTO `ssnh_webconfigs` VALUES ('webdomain', 'img.u9vip.com');
INSERT INTO `ssnh_webconfigs` VALUES ('webqq', '2839868773');
INSERT INTO `ssnh_webconfigs` VALUES ('symb', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('web_index_gg', '');
INSERT INTO `ssnh_webconfigs` VALUES ('web_control_gg', '');
INSERT INTO `ssnh_webconfigs` VALUES ('web_shop_gg', '');
INSERT INTO `ssnh_webconfigs` VALUES ('webfree', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('price_1dvip', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('regrmb', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('web_rmb_gg', '');
INSERT INTO `ssnh_webconfigs` VALUES ('name', '澄空同学录V2.0');
INSERT INTO `ssnh_webconfigs` VALUES ('syyy', '2839868773');
INSERT INTO `ssnh_webconfigs` VALUES ('bjys', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('bjzy', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('bjss', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('wzgg', '澄空同学录V2.0 正式更新发布，此版本我要感谢大家对悠久工作室的支持！此版本相对来说较完善，若发现有bug或有你的好的建议或看法，可以联系作者QQ2839868773提出来，非诚勿扰！');
INSERT INTO `ssnh_webconfigs` VALUES ('bjgg', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('jhhd', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('bjhd', '澄空同学录V2.0 更新发布咯');
INSERT INTO `ssnh_webconfigs` VALUES ('webmail', '2839868773@qq.com');
INSERT INTO `ssnh_webconfigs` VALUES ('webphone', '13777930544');
INSERT INTO `ssnh_webconfigs` VALUES ('webaddress', '浙江省宁波市');
INSERT INTO `ssnh_webconfigs` VALUES ('sfbfq', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('bjmm', '123456');
INSERT INTO `ssnh_webconfigs` VALUES ('zc', '1');
INSERT INTO `ssnh_webconfigs` VALUES ('qqjk', 'http://lqq.25ak.com/quan.php?jx=');
INSERT INTO `ssnh_webconfigs` VALUES ('smusic', 'http://api.qq-admin.cn/?mod=QQMusicJs&qq=');
INSERT INTO `ssnh_webconfigs` VALUES ('zxyy', 'TinVSYyyi1');
INSERT INTO `ssnh_webconfigs` VALUES ('gfqq', 'http://wpa.qq.com/msgrd?v=3&uin=2839868773&site=qq&menu=yes');
INSERT INTO `ssnh_webconfigs` VALUES ('spvid', 'u00139g552o');
INSERT INTO `ssnh_webconfigs` VALUES ('dlzc', '澄空');
INSERT INTO `ssnh_webconfigs` VALUES ('webbq', '澄空同学录');
INSERT INTO `ssnh_webconfigs` VALUES ('sqq', 'http://www.xzfuli.cn/index.php?url=');
INSERT INTO `ssnh_webconfigs` VALUES ('sqwz', 'http://sq.34ban.top');
INSERT INTO `ssnh_webconfigs` VALUES ('yx4', '我要好看的壁纸');
INSERT INTO `ssnh_webconfigs` VALUES ('yx4wl', 'http://movie.anqianle.cn/bizhi/');
INSERT INTO `ssnh_webconfigs` VALUES ('zbsqm', '余姚二中|高一（3）班');
INSERT INTO `ssnh_webconfigs` VALUES ('symusic', '28941006');
INSERT INTO `ssnh_webconfigs` VALUES ('music', '746548389');
INSERT INTO `ssnh_webconfigs` VALUES ('gxsj', '2017-10-21—00：00：00');
INSERT INTO `ssnh_webconfigs` (`vkey`, `value`) VALUES ('web_ifreg', '1');
INSERT INTO `ssnh_webconfigs` (`vkey`, `value`) VALUES ('web_iflogin', '1');
DROP TABLE IF EXISTS `ssnh_xc`;
CREATE TABLE `ssnh_xc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dz` varchar(255) NOT NULL,
  `ms` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS `ssnh_lyb`;
CREATE TABLE `ssnh_lyb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qq` text,
  `user` text,
  `info` text,
  `time` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
