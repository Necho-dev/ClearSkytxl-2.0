<?php
require_once('../common.php');
require_once('head.php');
?>
<body class="gray-bg">
    <div class="wrapper wrapper-content animated fadeInRight">
   <center> <h2 class="font-bold">嘿！没错这就是班级的中心哟</h2></center>
 <div class="row">
            <div class="col-sm-4">
                <div class="widget-head-color-box navy-bg p-lg text-center">
                    
                    <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$userrow['qq']?>&s=160" class="img-circle circle-border m-b-md" alt="profile">
                       <div>
                        <h2 class="font-bold no-margins"><?=$userrow['xm']?></h2> 
                    </div>
                    <div>
                        <span><?=$userrow['gxqm']?></span> 
                    </div>

                </div>
                <div class="widget lazur-bg p-lg">
                    <p>用户名:<?=$userrow['user']?></p>
                    <p>权限:
                                    <?php
                                   if ($userrow['active']==9) {
                                   echo "Svip-超级站长";
                                   }elseif ($userrow['active']==8) {
                                   echo "vip-副站长";
                                   }elseif ($userrow['active']==7) {
                                    echo "我是老师";
                                    }elseif ($userrow['active']==6) {
                                    echo "我是班长";
                                   }elseif ($userrow['active']==5) {
                                    echo "我是课代表";
                                   }else{
                                    echo "学生一枚";
                                   }
                                  ?></p>
                    <p>QQ:<?=$userrow['qq']?></p>
                    <p>Call:<?=$userrow['phone']?></p>

                </div>
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=210 src="//music.163.com/outchain/player?type=0&id=<?=C('music')?>&auto=1&height=430"></iframe>
                 
            </div>
            <div class="col-sm-8">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5><?php echo date('m-d') ?>班级公告 <small class="m-l-sm">看！班级里有人搞事情了，求围观</small></h5>
                    </div>
                    <div class="ibox-content">
网站公告：<?=C('wzgg')?></p>
班级公告：<?=C('bjgg')?></p>
班级要事：<?=C('bjys')?></p>
重要事项：<?=C('bjss')?></p>
班级活动：<?=C('bjhd')?></p>
聚会活动：<?=C('jhhd')?></p>
伐木累：<?=C('zbsqm')?></p>
网站版权：<?=C('webbq')?>
                                        <br>
<br>
<br> 更新时间：<?=C('gxsj')?>
                    </div>
                </div>
                </div>
                 <div class="col-sm-4">
                 <div class="widget-text-box">
                    <div class="m-b-md">
                        <center><i class="glyphicon glyphicon-tag fa-3x"></i>
                        <h3 class="font-bold no-margins">
                                当前日期
                            </h3>
                            
                            <hr>
                        <h2><?php echo date('m-d') ?></h2></center>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                 <div class="widget-text-box">
                    <div class="m-b-md">
                        <center><i class="glyphicon glyphicon-time fa-3x"></i>
                        <h3 class="font-bold no-margins">
                               当前时间
                            </h3>
                            
                            <hr>
                        <center> <h2><?php echo date('H:i:s') ?></h2></center>
                    </div>
                </div>
            </div>

            </div>
        </div>

<?php
require_once('foot.php');
?>

