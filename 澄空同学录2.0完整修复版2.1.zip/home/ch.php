
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="dns-prefetch" href="//s1.tool.lu">
    <link rel="dns-prefetch" href="//s2.tool.lu">
    <link rel="dns-prefetch" href="//s3.tool.lu">
    <link rel="dns-prefetch" href="//s4.tool.lu">
    <link rel="dns-prefetch" href="//analytics.tool.lu">
    <title>历史朝代表 - 在线工具</title>
    <link rel="search" type="application/opensearchdescription+xml" title="在线工具"
          href="http://tool.lu/opensearch.xml">
    <meta property="wb:webmaster" content="b937d84f38f5d296">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="iteam">
    <link rel="publisher" href="https://plus.google.com/113621341737546487026">
    <meta name="keywords" content="历史朝代表">
    <meta name="description" content="历史朝代表">
    <link rel="shortcut icon" href="http://tool.lu/favicon.ico">
    <!--[if lt IE 9]>
    <script src="//s1.tool.lu/??js/html5shiv.js,js/es5-shim.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="//s2.tool.lu/??css/font-awesome.min.css,css/style.css,css/icons.css,css/g-nav.css,js/tipsy.css,js/facebox/facebox.css,js/nprogress/nprogress.css,js/waves/waves.min.css,js/unslider/css/unslider.css?t=1501736565">
    <!-- <script src="//analytics.tool.lu/te.js" crossorigin="anonymous"></script> -->
    <script src="//s3.tool.lu/??js/jquery.min.js,js/jquery-ui.min.js,js/underscore-min.js,js/unslider/js/unslider-min.js,js/jquery.topLink.js,js/draggabilly/draggabilly.pkgd.min.js,js/jquery.generateFile.js,js/facebox/facebox.js,js/clipboard/clipboard.min.js,js/jquery.fullscreen.js,js/jquery.tipsy.js,js/jquery-scrolltofixed-min.js,js/mousetrap.min.js,js/helpers.js,js/base.js?t=1501736565"></script>
    </head>
<body>
<!--[if lt IE 9]>
<div class="notice chromeframe">您的浏览器版本<strong>很旧很旧</strong>，为了正常地访问网站，请升级您的浏览器 <a target="_blank"
                                                                                   href="http://browsehappy.com">立即升级</a>
</div>
<![endif]-->
         </p>
            </form>
            <div id="eles">
                <ul>
                    <li>
                        
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div id="nav">
        <div class="w">
            <div class="nav-inner clearfix">
                
            </div>
        </div>
    </div>
    <div id="bdy">
        <div class="w">
<div class="main">
    <div class="inner">
        <table class="tbl" width="100%" cellspacing="0" cellpadding="0">
            <thead>
            <tr>
                <th colspan="2">
                    朝 代
                </th>
                <th>
                    起 讫
                </th>
                <th>
                    都 城
                </th>
                <th>
                    今 地
                </th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th colspan="2">
                    夏
                </th>
                <td>
                    约前2146-1675年
                </td>
                <td>
                    安邑
                </td>
                <td>
                    山西夏县
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <span>①商</span>
                </th>
                <td>
                    约前1675-1029年
                </td>
                <td>
                    亳
                </td>
                <td>
                    河南商丘
                </td>
            </tr>
            <tr>
                <th rowspan="2">
                    周
                </th>
                <th>
                    西周
                </th>
                <td>
                    <span>②约前1029-771年</span>
                </td>
                <td>
                    镐京
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th>
                    东周
                </th>
                <td>
                    前770-256年
                </td>
                <td>
                    洛邑
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    秦
                </th>
                <td>
                    前221-207年
                </td>
                <td>
                    咸阳
                </td>
                <td>
                    陕西咸阳
                </td>
            </tr>
            <tr>
                <th rowspan="2">
                    汉
                </th>
                <th>
                    <span>③西汉</span>
                </th>
                <td>
                    前206—公元25
                </td>
                <td>
                    长安
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th>
                    东汉
                </th>
                <td>
                    25—220
                </td>
                <td>
                    洛阳
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th rowspan="3">
                    三国
                </th>
                <th>
                    魏
                </th>
                <td>
                    220-265
                </td>
                <td>
                    洛阳
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th>
                    蜀
                </th>
                <td>
                    221-263
                </td>
                <td>
                    成都
                </td>
                <td>
                    四川成都
                </td>
            </tr>
            <tr>
                <th>
                    吴
                </th>
                <td>
                    222-280
                </td>
                <td>
                    建业
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    西晋
                </th>
                <td>
                    265-317
                </td>
                <td>
                    洛阳
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th rowspan="2">
                    东晋<br>
                    十六国
                </th>
                <th>
                    东晋
                </th>
                <td>
                    317-420
                </td>
                <td>
                    建康
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th>
                    <span>④十六国</span>
                </th>
                <td>
                    304-439
                </td>
                <td>
                    —
                </td>
                <td>
                    —
                </td>
            </tr>
            <tr>
                <th rowspan="4">
                    南朝
                </th>
                <th>
                    宋
                </th>
                <td>
                    420-479
                </td>
                <td>
                    建康
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th>
                    齐
                </th>
                <td>
                    479-502
                </td>
                <td>
                    建康
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th>
                    梁
                </th>
                <td>
                    502-557
                </td>
                <td>
                    建康
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th>
                    陈
                </th>
                <td>
                    557-589
                </td>
                <td>
                    建康
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <th rowspan="6">
                    北朝
                </th>
                <th rowspan="2">
                    北魏
                </th>
                <td rowspan="2">
                    386-534
                </td>
                <td>
                    平城
                </td>
                <td>
                    山西大同
                </td>
            </tr>
            <tr>
                <td>
                    洛阳
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th>
                    东魏
                </th>
                <td>
                    534-550
                </td>
                <td>
                    邺
                </td>
                <td>
                    河北临漳
                </td>
            </tr>
            <tr>
                <th>
                    北齐
                </th>
                <td>
                    550-577
                </td>
                <td>
                    邺
                </td>
                <td>
                    河北临漳
                </td>
            </tr>
            <tr>
                <th>
                    西魏
                </th>
                <td>
                    535-557
                </td>
                <td>
                    长安
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th>
                    北周
                </th>
                <td>
                    557-581
                </td>
                <td>
                    长安
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    隋
                </th>
                <td>
                    581-618
                </td>
                <td>
                    大兴
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    唐
                </th>
                <td>
                    618-907
                </td>
                <td>
                    长安
                </td>
                <td>
                    陕西西安
                </td>
            </tr>
            <tr>
                <th rowspan="6">
                    五代<br>
                    十国
                </th>
                <th>
                    后梁
                </th>
                <td>
                    907-923
                </td>
                <td>
                    汴
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th>
                    后唐
                </th>
                <td>
                    923-936
                </td>
                <td>
                    洛阳
                </td>
                <td>
                    河南洛阳
                </td>
            </tr>
            <tr>
                <th>
                    后晋
                </th>
                <td>
                    936-946
                </td>
                <td>
                    汴
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th>
                    后汉
                </th>
                <td>
                    947-950
                </td>
                <td>
                    汴
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th>
                    后周
                </th>
                <td>
                    951-960
                </td>
                <td>
                    汴
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th>
                    <span>⑤十国</span>
                </th>
                <td>
                    902-979
                </td>
                <td>
                    —
                </td>
                <td>
                    —
                </td>
            </tr>
            <tr>
                <th rowspan="2">
                    宋
                </th>
                <th>
                    北宋
                </th>
                <td>
                    960-1127
                </td>
                <td>
                    开封
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th>
                    南宋
                </th>
                <td>
                    1127-1279
                </td>
                <td>
                    临安
                </td>
                <td>
                    浙江杭州
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    辽
                </th>
                <td>
                    907-1125
                </td>
                <td>
                    皇都(上京)
                </td>
                <td>
                    内蒙古&nbsp;巴林左旗
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    西夏
                </th>
                <td>
                    1038-1227
                </td>
                <td>
                    兴庆府
                </td>
                <td>
                    宁夏银川
                </td>
            </tr>
            <tr>
                <th rowspan="3" colspan="2">
                    金
                </th>
                <td rowspan="3">
                    1115-1234
                </td>
                <td>
                    会宁
                </td>
                <td>
                    阿城(黑龙江)
                </td>
            </tr>
            <tr>
                <td>
                    中都
                </td>
                <td>
                    北京
                </td>
            </tr>
            <tr>
                <td>
                    开封
                </td>
                <td>
                    河南开封
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    元
                </th>
                <td>
                    1206-1368
                </td>
                <td>
                    大都
                </td>
                <td>
                    北京
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    明
                </th>
                <td>
                    1368-1644
                </td>
                <td>
                    北京
                </td>
                <td>
                    北京
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    清
                </th>
                <td>
                    1616-1911
                </td>
                <td>
                    北京
                </td>
                <td>
                    北京
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    中华民国
                </th>
                <td>
                    1912-1949
                </td>
                <td>
                    南京
                </td>
                <td>
                    江苏南京
                </td>
            </tr>
            <tr>
                <td colspan="5" style="text-align:center">
                    <strong>中华人民共和国1949年10月1日成立，首都北京。</strong>
                </td>
            </tr>
            <tr>
                <td colspan="5">
                    附注：
                    <br>
                    ① 约公元前14世纪盘庚迁都于殷，此后商也成为殷。
                    <br>
                    ② 公元前841年(西周共和元年)为中国历史确切纪年的开始。
                    <br>
                    ③ 包括王莽建立的"新"王朝(公元8年—23年)。王莽时期，爆发大规模的农民起义，建立了农民政权。公元23年，新王莽政权灭亡。公元25年，东汉王朝建立。
                    <br>
                    ④ 这时期，在我国北方，先后存在过一些封建政权，其中有：汉(前赵)、成(成汉)、前凉、后赵(魏)、前燕、前秦、后燕、后秦、西秦、后凉、南凉、北凉、南燕、西凉、北燕、夏等国，历史上叫做"十六国"。
                    <br>
                    ⑤ 这时期，除后梁、后唐、后晋、后汉、后周外，还先后存在过一些封建政权，其中有：吴、前蜀、吴越、楚、闽、南汉、荆南(南平)、后蜀、南唐、北汉等国，历史上叫做"十国"。
                </td>
            </tr>
            </tbody>
        </table>
       
    </div>
</div>
<div class="aside hidden-xs hidden-sm">
    <div class="inner mgb10">
                    
                    <div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone"
data-cmd="qzone"
                                                                                          title="分享到QQ空间"></a><a
                href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_tsina"
                                                                               data-cmd="tsina" title="分享到新浪微博"></a><a
                href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_copy"
                                                                                   data-cmd="copy" title="分享到复制网址"></a>
        </div>
        <script>window._bd_share_config = {
                "common": {
                    "bdSnsKey": {},
                    "bdSign": "on",
                    "bdText": "",
                    "bdMini": "2",
                    "bdMiniList": false,
                    "bdPic": "",
                    "bdStyle": "1",
                    "bdSize": "16"
                }, "share": {}
            };
            with (document)0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];</script>
    </div>
    <div class="inner mgb10">
        <p style="margin: 0;"></p>
    </div>
            <div class="inner mgb10">
            <div class="panel">
                <div class="panel-heading">
                    
                    <!-- 收藏按钮 todo -->
                </div>
                <div class="panel-body">
                                            
                                <i
                                    class="fa fa-envelope-o"></i></a> <i class="medal-zz"></i></span>
感谢使用澄空同学录！！！
                                    </div>
            </div>
        </div>
            <!--
    <div class="adsense inner mgb10">
        <script>
            /*200*200，创建于2014-6-26*/
            var cpro_id = "u2345421";
        </script>
        <script src="http://cpro.baidustatic.com/cpro/ui/c.js"></script>
    </div>
    -->
    <div class="note">
        <div class="note-container">
            其实美丽的故事都是没有结局的，只因为它没有结局所以才会美丽。这就像为什麽悲剧总是比喜剧更让人难忘，也就像人们总是找寻的真爱，却往往擦肩而去，不是这个时代远离了爱情，而是人们一开始就没有想过用一颗心去坚定的温暖另一颗心，不是爱情不再永恒，而是浮躁和易变的心！        </div>
        <div class="note-bottom"></div>
</div>
</div>
</div>
<div id="ftr">
    <div class="w">
        <p class="declare">
           
            <script>
                (function () {
                    var protocol = 'https:' == document.location.protocol ? 'https://' : 'http://';
                    document.write(unescape("%3Cscript src='" + protocol + "hm.baidu.com/h.js%3F0fba23df1ee7ec49af558fb29456f532'%3E%3C/script%3E"));
                    var _timer,
                        _fold = false;
                    $('.dropdown').on('mouseenter mouseleave', function (e) {
                        var _this = $(this),
                            _toolList = $('.toolList');
                        if (e.type === 'mouseenter') {
                            _timer = setTimeout(function () {
                                _toolList.stop(1, 1).slideDown({duration: 300});
                                _this.width(450);
                                _fold = true;
                            }, 100);
                        } else {
                            if (!_fold && _timer) {
                                clearTimeout(_timer);
                            } else {
                                _toolList.stop(1, 1).slideUp({duration: 300});
                                _this.width('auto');
                                _fold = false;
                            }
                        }
                    });
                })();
            </script>
            <br>
            Copyright &copy; 2011-2017 iteam All
            Rights Reserved. Current version is 澄空同学录.
            <br>
           
            
        </p>
    </div>
</div>
</div>
<div id="t_fixed">
    <a target="_blank" class="btn qq-qun copy-btn js-tip"
    <a target="_blank" class="btn weibo js-tip" href="http://weibo.com/6106073484" title="微博@孤酒巷痞<">孤酒巷痞</a>
    <a class="btn gotop js-tip" href="javascript:;" onclick="window.scrollTo('0','0')" title="返回顶部">返回顶部</a>
</div>
<script>
    (function () {
        var a = document.createElement("script");
        a.async = !0;
        a.src = ("https:" == document.location.protocol ? "https:" : "http:") + "//analytics.tool.lu/ta.js";
        var b = document.getElementsByTagName("script")[0];
        b.parentNode.insertBefore(a, b)
    })();
</script>
<script src="//s2.tool.lu/??js/track.js"></script>
<script src="//s3.tool.lu/??js/waves/waves.min.js,js/nprogress/nprogress.js,js/main.js"></script>
</body>
</html>
